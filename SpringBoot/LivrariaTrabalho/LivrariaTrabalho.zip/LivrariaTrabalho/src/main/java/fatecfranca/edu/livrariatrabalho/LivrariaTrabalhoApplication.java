package fatecfranca.edu.livrariatrabalho;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LivrariaTrabalhoApplication {

    public static void main(String[] args) {
        SpringApplication.run(LivrariaTrabalhoApplication.class, args);
    }

}
