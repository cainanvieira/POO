package fatecfranca.edu.livrariatrabalho.service;
import fatecfranca.edu.livrariatrabalho.model.dto.LivrariaDTO;
import fatecfranca.edu.livrariatrabalho.model.entity.Livraria;
import org.springframework.stereotype.Service;

@Service
public class LivrariaService {
    LivroService injecaoLivro;

    public LivrariaDTO converteEntity(Livraria livraria) {
        return new LivrariaDTO(livraria.getTelefone(),
                livraria.getNome(),
                livraria.getCnpj(),
                livraria.getEndereco(),
                injecaoLivro.converteEntities(livraria.getLivros()));
    }
    public Livraria converteDTO(LivrariaDTO livrariaDTO) {
        return new Livraria(livrariaDTO.getTelefone(),
                livrariaDTO.getNome(),
                livrariaDTO.getCnpj(),
                livrariaDTO.getEndereco(),
                injecaoLivro.converteDTOs(livrariaDTO.getLivros()));
    }
}
