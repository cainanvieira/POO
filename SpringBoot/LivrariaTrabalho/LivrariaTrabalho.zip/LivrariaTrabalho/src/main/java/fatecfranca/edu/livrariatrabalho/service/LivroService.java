package fatecfranca.edu.livrariatrabalho.service;
import fatecfranca.edu.livrariatrabalho.model.dto.LivroDTO;
import fatecfranca.edu.livrariatrabalho.model.entity.Livro;
import fatecfranca.edu.livrariatrabalho.model.repository.LivroRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class LivroService {

    @Autowired
    LivroRepository injecao;

    @Autowired
    LivrariaService injecaoLivraria;

    public LivroDTO createLivro(LivroDTO livroDTO) {
        Livro livro = converteDTO(livroDTO);
        Livro novoLivro = injecao.save(livro);
        return converteEntity(novoLivro);
    }

    public String removeLivro(Long id) {
        if (injecao.existsById(id)) {
            injecao.deleteById(id);
            return "Removido com sucesso";
        } else {
            return "O livro informado não existe";
        }
    }

    public List<LivroDTO> listaLivros() {
        return converteEntities(injecao.findAll());
    }

    public LivroDTO listaLivros(Long id) {
        if (injecao.existsById(id)) {
            Optional<Livro> aux = injecao.findById(id);
            if (aux.isPresent()) {
                return converteEntity(aux.get());
            } else {
                return null;
            }
        }
        return null;
    }

    public List<LivroDTO> aplicaDesconto() {
        List<Livro> livros = injecao.findAll();
        int count = 0;
        // Aplica o desconto de 50% de desconto no segundo livro
        for (Livro livro : livros) {
            if (count % 2 != 0) { // Verifica se é o segundo livro
                livro.setPreco(livro.getPreco() * 0.5f); // Aplica o desconto de 50%
            }
            count++;
        }
        injecao.saveAll(livros);
        return converteEntities(livros);
    }

    public LivroDTO atualizaPorId(Long id, LivroDTO livroDTO) {
        if (injecao.existsById(id)) {
            livroDTO.setId(id);
            Livro livroAtualizado = injecao.save(converteDTO(livroDTO));
            return converteEntity(livroAtualizado);
        } else {
            return null;
        }
    }

    public Livro converteDTO(LivroDTO livroDTO) {
        return new Livro(livroDTO.getId(),
                livroDTO.getNome(),
                livroDTO.getAutor(),
                livroDTO.getQtde(),
                livroDTO.getPreco(),
                injecaoLivraria.converteDTO(livroDTO.getLivraria()));
    }

    public LivroDTO converteEntity(Livro livro) {
        return new LivroDTO(livro.getId(),
                livro.getNome(),
                livro.getAutor(),
                livro.getQtde(),
                livro.getPreco(),
                injecaoLivraria.converteEntity(livro.getLivraria()));
    }

    public List<LivroDTO> converteEntities(List<Livro> livros) {
        List<LivroDTO> livrosDTO = new ArrayList<LivroDTO>();
        for (Livro livro : livros) {
            livrosDTO.add(converteEntity(livro));
        }
        return livrosDTO;
    }

    public List<Livro> converteDTOs(List<LivroDTO> livrosDTO) {
        List<Livro> livros = new ArrayList<Livro>();
        for (LivroDTO livroDTO : livrosDTO) {
            livros.add(converteDTO(livroDTO));
        }
        return livros;
    }
}
