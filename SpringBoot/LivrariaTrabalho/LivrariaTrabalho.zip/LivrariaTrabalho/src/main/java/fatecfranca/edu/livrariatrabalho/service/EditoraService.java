package fatecfranca.edu.livrariatrabalho.service;
import fatecfranca.edu.livrariatrabalho.model.dto.EditoraDTO;
import fatecfranca.edu.livrariatrabalho.model.entity.Editora;

public class EditoraService {
    LivroService injecaoLivro;

    public EditoraDTO converteEntity(Editora editora) {
        return new EditoraDTO(editora.getTelefone(),
                editora.getNome(),
                editora.getCnpj(),
                editora.getEndereco(),
                editora.getEmail(),
                injecaoLivro.converteEntities(editora.getLivros()));
    }

    public Editora converteDTO(EditoraDTO editoraDTO) {
        return new Editora(editoraDTO.getTelefone(),
                editoraDTO.getNome(),
                editoraDTO.getCnpj(),
                editoraDTO.getEndereco(),
                editoraDTO.getEmail(),
                injecaoLivro.converteDTOs(editoraDTO.getLivros()));
    }
}

