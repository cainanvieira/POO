package fatecfranca.edu.livrariatrabalho.model.dto;
import lombok.*;

@Getter
@Setter
@EqualsAndHashCode
@AllArgsConstructor
@NoArgsConstructor

public class LivroDTO {
    private Long id;
    private String nome, autor;
    private int qtde;
    private float preco;
    private LivrariaDTO livraria;
}