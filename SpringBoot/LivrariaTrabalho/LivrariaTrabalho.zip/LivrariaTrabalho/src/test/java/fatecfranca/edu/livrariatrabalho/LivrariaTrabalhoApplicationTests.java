package fatecfranca.edu.livrariatrabalho;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LivrariaTrabalhoApplicationTests {

    @Test
    void contextLoads() {
    }

}
